Font source for Luoyang WeiBei Unicode. GNU GPL v2 or later.
Original: https://github.com/cghio/wangfonts
Changes: Unicode cmap aliases and family naming; glyph outlines unchanged.
Rebuild: install fonttools, then python3 scripts/build-font.py.
The script checks the font cmap and writes docs/FONT_CHECK.json.
