"""Add missing Unicode aliases to the original WeiBei without changing outlines.

Requires fonttools. The OpenCC dictionary and its license are kept with the source.
Existing mappings always win. Newly aliased characters reuse the original glyphs.
"""
from pathlib import Path
import json
import re
from fontTools.ttLib import TTFont

ROOT = Path(__file__).resolve().parents[1]
original = ROOT / 'dist/assets/wts43.ttf'
destination = ROOT / 'dist/assets/luoyang-weibei.ttf'
dictionary = ROOT / 'artwork/ink-v2/STCharacters.txt'
font = TTFont(original, recalcTimestamp=False)
original_cmap = font.getBestCmap().copy()
aliases = {}
for line in dictionary.read_text().splitlines():
    if not line or line.startswith('#') or '\t' not in line:
        continue
    simplified, variants = line.split('\t', 1)
    if len(simplified) != 1 or ord(simplified) in original_cmap:
        continue
    target = next((ch for ch in variants.split() if len(ch) == 1 and ord(ch) in original_cmap), None)
    if target:
        aliases[ord(simplified)] = original_cmap[ord(target)]
# Taiwan / classical orthographic variants not present in the generic dictionary.
for source, target in {'为':'為','众':'眾','启':'啟','着':'著'}.items():
    if ord(source) not in original_cmap and ord(target) in original_cmap:
        aliases[ord(source)] = original_cmap[ord(target)]
# Orthographic variant used by the quoted Siku text: 埓 / 埒.
if ord('埓') not in original_cmap and ord('埒') in original_cmap:
    aliases[ord('埓')] = original_cmap[ord('埒')]
for table in font['cmap'].tables:
    if table.isUnicode():
        table.cmap.update({cp: glyph for cp, glyph in aliases.items() if cp <= 0xFFFF or table.format == 12})
names = {1:'Luoyang WeiBei Unicode', 2:'Regular', 3:'LuoyangWeiBeiUnicode-1.0',
         4:'Luoyang WeiBei Unicode', 6:'LuoyangWeiBeiUnicode',
         16:'Luoyang WeiBei Unicode', 17:'Regular'}
for record in font['name'].names:
    if record.nameID in names:
        record.string = names[record.nameID].encode(record.getEncoding(), errors='replace')
font.save(destination)
derived = TTFont(destination)
assert derived.getGlyphOrder() == font.getGlyphOrder()
assert derived.getTableData('glyf') == font.getTableData('glyf'), 'Outlines changed'
ui = ''.join(p.read_text() for p in (ROOT/'dist').glob('*.js')) + (ROOT/'dist/index.html').read_text()
characters = set(re.findall('[\u3400-\u9fff]', ui))
cmap = derived.getBestCmap()
missing = sorted(ch for ch in characters if ord(ch) not in cmap)
assert not missing, f'Missing UI characters: {missing}'
report = {'family':names[1], 'unicode_aliases_added':len(aliases),
          'ui_han_characters_checked':len(characters), 'missing_ui_characters':missing,
          'original_glyph_outlines_unchanged':True}
(ROOT/'docs/FONT_CHECK.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False))
